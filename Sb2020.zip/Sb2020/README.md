Installation for Termux

$ apt update

$ apt upgrade

$ apt install python

$ apt install git

$ git clone https://github.com/AkiraOrizaya/Sb2020
$ cd NewSB

$ python -m pip install -r requirements.txt

$ python3 sby.py

------------------------------

Installation for VPS

$ git clone https://github.com/AkiraOrizaya/Sb2020

$ cd NewSB

$ python3 -m pip install -r requirements.txt

$ python3 sby.py

